<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://www.companyname.com
 * @since             1.0.0
 * @package           Ps_Wp_Chat
 *
 * @wordpress-plugin
 * Plugin Name:       Dancer
 * Plugin URI:        https://companyname.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            John Doe
 * Author URI:        http://www.companyname.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

function geek_dance_database_table_callback(){
    global $table_prefix, $wpdb;

      /*
    if($wpdb->get_var( "show tables like '$wp_dance_table'" ) != $wp_dance_table) {
        $sql = "CREATE TABLE `". $wp_dance_table ."` (";
		 $sql .= "`id` int(10) NOT NULL AUTO_INCREMENT,";
		 $sql .= "`rpl_id` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`from_user_id` int(10) NOT NULL,";
		 $sql .= "`to_user_id` int(10) NOT NULL,";
		 $sql .= "`subject` varchar(100) NOT NULL,";
		 $sql .= "`message` text NOT NULL,";
		 $sql .= "`save_as_outbox` int(10) NOT NULL,";
		 $sql .= "`readable` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  readable',";
		 $sql .= "`created_date` datetime NOT NULL,";
		 $sql .= "`ip_address` varchar(100) NOT NULL,";
		 $sql .= "PRIMARY KEY (`id`)";
		$sql .= ") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";

        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }
    */

    $tblname = 'geek_dance_participants';
    $wp_dance_table = $table_prefix . "$tblname";

    /*Geek Dance Participant Table*/
    if($wpdb->get_var( "show tables like '$wp_dance_table'" ) != $wp_dance_table) {
        $sql = "CREATE TABLE `". $wp_dance_table ."` (";
		 $sql .= "`id` int(10) NOT NULL AUTO_INCREMENT,";
		 $sql .= "`competition_id` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`name` varchar(100) NOT NULL,";
		 $sql .= "`email` varchar(100) NOT NULL,";
		 $sql .= "`age` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`entry_no` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`cda` int(11) NOT NULL DEFAULT '0' COMMENT '1 =  CDA',";
		 $sql .= "`cda_code` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`evaluation_form` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  contempory, 1 = classical, 2 = both',";
		 $sql .= "`title` varchar(100) NOT NULL,";
		 $sql .= "`photo_name` varchar(100) NOT NULL,";
		 $sql .= "`created_date` datetime NOT NULL,";
		 $sql .= "PRIMARY KEY (`id`)";
		$sql .= ") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";

        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }

    /*Geek Dance Participant Meta Table*/
    $tblname = 'geek_dance_participants_meta';
    $wp_dance_table = $table_prefix . "$tblname";
    if($wpdb->get_var( "show tables like '$wp_dance_table'" ) != $wp_dance_table) {
        $sql = "CREATE TABLE `". $wp_dance_table ."` (";
		 $sql .= "`id` int(10) NOT NULL AUTO_INCREMENT,";
		 $sql .= "`competition_id` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`participant_id` int(11) NOT NULL DEFAULT '0',";
		 $sql .= "`judge_id` int(11) NOT NULL DEFAULT '0',";

		 $sql .= "`clarity` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`turn_out` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`foot_work` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`elevation` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`port_de_bras` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`extension` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`technique_score` int(11) NOT NULL DEFAULT '0' COMMENT 'Out of 50',";

		 $sql .= "`expression` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`musicality` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`presentation` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`style` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`dynamics` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`use_of_space` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  Need Work, 1 = Good Work',";
		 $sql .= "`artistry_score` int(11) NOT NULL DEFAULT '0' COMMENT 'Out of 50',";

		 $sql .= "`total_score` int(11) NOT NULL DEFAULT '0' COMMENT 'Sum of technique_score + artistry_score',";
		 $sql .= "`general_notes` text NOT NULL,";
		 $sql .= "`created_date` datetime NOT NULL,";
		 $sql .= "PRIMARY KEY (`id`)";
		$sql .= ") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";

        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }


    /*Geek Dance Competition Table*/
	$tblname = 'geek_dance_competitions';
    $wp_dance_table = $table_prefix . "$tblname";
    if($wpdb->get_var( "show tables like '$wp_dance_table'" ) != $wp_dance_table) {
        $sql = "CREATE TABLE `". $wp_dance_table ."` (";
		 $sql .= "`id` int(10) NOT NULL AUTO_INCREMENT,";
		 $sql .= "`parent_id` int(10) NOT NULL,";
		 $sql .= "`title` varchar(100) NOT NULL,";
		 $sql .= "`evaluation_form` varchar(100) NOT NULL,";
		 $sql .= "`type` varchar(100) NOT NULL,";
		 $sql .= "`status` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  inactive, 1 = active',";
		 $sql .= "`final_date` datetime NOT NULL,";
		 $sql .= "`created_date` datetime NOT NULL,";
		 $sql .= "PRIMARY KEY (`id`)";
		$sql .= ") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";

        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }


    /*Geek Dance Parent Competition Table*/
	$tblname = 'geek_dance_parent_competitions';
    $wp_dance_table = $table_prefix . "$tblname";
    if($wpdb->get_var( "show tables like '$wp_dance_table'" ) != $wp_dance_table) {
        $sql = "CREATE TABLE `". $wp_dance_table ."` (";
		 $sql .= "`id` int(10) NOT NULL AUTO_INCREMENT,";
		 $sql .= "`title` varchar(100) NOT NULL,";
		 $sql .= "`status` int(11) NOT NULL DEFAULT '0' COMMENT '0 =  inactive, 1 = active',";
		 $sql .= "`final_date` datetime NOT NULL,";
		 $sql .= "`created_date` datetime NOT NULL,";
		 $sql .= "PRIMARY KEY (`id`)";
		$sql .= ") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;";

        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }
    

    $post_title = 'Login';
	$geek_dance_page = array(
	    'post_title'    => $post_title,
	    'post_content'  => '[geek_dance_login]',
	    'post_status'   => 'publish',
	    'post_author'   => 1,
	    'post_name'		=> 'geek-dance-login',
	    'post_type'   	=> 'page'
	);
	// Insert the post into the data
	$page_id = post_exists( $post_title ) or wp_insert_post( $geek_dance_page );
	if($page_id > 0)
		update_option('geek_dance_login', $page_id);


	$post_title = 'Registration';
	$geek_dance_page = array(
	    'post_title'    => $post_title,
	    'post_content'  => '[geek_dance_registration]',
	    'post_status'   => 'publish',
	    'post_author'   => 1,
	    'post_name'		=> 'geek-dance-registration',
	    'post_type'   	=> 'page'
	);
	// Insert the post into the data
	$page_id = post_exists( $post_title ) or wp_insert_post( $geek_dance_page );
	if($page_id > 0)
		update_option('geek_dance_registration', $page_id);


    $post_title = 'Participants';
	$geek_dance_page = array(
	    'post_title'    => $post_title,
	    'post_content'  => '[geek_dance_participants]',
	    'post_status'   => 'publish',
	    'post_author'   => 1,
	    'post_name'		=> 'geek-dance-participants',
	    'post_type'   	=> 'page'
	);
	// Insert the post into the data
	$page_id = post_exists( $post_title ) or wp_insert_post( $geek_dance_page );
	if($page_id > 0)
		update_option('geek_dance_participants_page_id', $page_id);


	
	$post_title = 'Competitions';
	$geek_dance_private_message = array(
	    'post_title'    => $post_title,
	    'post_content'  => '[geek_dance_competitions]',
	    'post_status'   => 'publish',
	    'post_author'   => 1,
	    'post_name'		=> 'geek-dance-competitions',
	    'post_type'   	=> 'page'
	);
	// Insert the post into the data
	$page_id = post_exists($post_title) or wp_insert_post( $geek_dance_private_message );
	if($page_id > 0)
		update_option('geek_dance_competitions_page_id', $page_id);

}

register_activation_hook( __FILE__, 'geek_dance_database_table_callback' );


function geek_dance_on_plugins_loaded(){
	global $table_prefix, $wpdb;

	$url = plugin_dir_url(__FILE__);
	define('GEEK_DANCE_PLUGIN_URL',$url);

	$dir = plugin_dir_path( __FILE__ );
	define('GEEK_DANCE_PLUGIN_DIR_PATH',$dir);

    $tblname = 'geek_dance_participants';
    $wp_dance_table = $table_prefix . "$tblname";
    define('GEEK_DANCE_PARTICIPANTS_TABLE', $wp_dance_table);

    $tblname = 'geek_dance_participants_meta';
    $wp_dance_table = $table_prefix . "$tblname";
    define('GEEK_DANCE_PARTICIPANTS_META_TABLE', $wp_dance_table);

    $tblname = 'geek_dance_competitions';
    $wp_dance_table = $table_prefix . "$tblname";
    define('GEEK_DANCE_COMPETITIONS_TABLE', $wp_dance_table);

    $tblname = 'geek_dance_parent_competitions';
    $wp_dance_table = $table_prefix . "$tblname";
    define('GEEK_DANCE_PARENT_COMPETITIONS_TABLE', $wp_dance_table);
	/*
	$geek_dance_participants_page_id 	=  get_option('geek_dance_participants_page_id');
	$geek_dance_competitions_page_id 	= get_option('geek_dance_competitions_page_id');

	$geek_dance_private_contact_id 		= get_option('geek_dance_private_contact');
	$geek_dance_outbox_message_id 		= get_option('geek_dance_outbox_message');

	define(GEEK_DANCE_READ_MESSAGE_PAGE_LINK, get_permalink($geek_dance_competitions_page_id));
	define(GEEK_DANCE_REPLY_MESSAGE_PAGE_LINK, get_permalink($geek_dance_reply_message_id));
	define(GEEK_DANCE_PRIVATE_CONTACT_PAGE_LINK, get_permalink($geek_dance_private_contact_id));
	define(GEEK_DANCE_OUTBOX_MESSAGE_PAGE_LINK, get_permalink($geek_dance_outbox_message_id));
	*/

	include_once 'includes/functions.php';
	include_once 'includes/shortcodes.php';
}
add_action('init', 'geek_dance_on_plugins_loaded');	 
