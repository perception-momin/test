/*
competition_id
name
age
entry_no
cda  0/1
cda_code
Evaluation form : checkbox Contempory or classical
title 
photo
created_date
*/


https://stackoverflow.com/questions/6006636/mysql-how-to-create-column-that-automatically-sums-rows

http://www.zaposphere.com/responsive-html-table-design-in-wordpress/