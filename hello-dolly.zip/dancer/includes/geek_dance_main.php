<?php
	global $wpdb; 
	$geek_dance_main_url 	= get_the_permalink();
	$competition_id			= $parent_competition_id = "";

	$current_module 		= 'competitions';
	$current_action 		= 'list_parent_competitions';

	if(isset($_GET['module']) && !empty($_GET['module'])){
		$current_module 	= $_GET['module'];
	}

	if(isset($_GET['action']) && !empty($_GET['action'])){
		$current_action 	= $_GET['action'];
	}


	if(isset($_GET['id']) && !empty($_GET['id'])){
		if($current_action == 'edit_parent_competition'){
			$parent_competition_id = $_GET['id'];	
		}else{
			$competition_id 	= $_GET['id'];	
		}
		
	}
?>


<nav>
   <ul>
      <li><a href="<?php echo $geek_dance_main_url ?>?module=competitions">Competitions</a></li>
      <li><a href="<?php echo $geek_dance_main_url ?>?module=participants">Participants</a></li>
      <li><a href="<?php echo $geek_dance_main_url ?>?module=judges">Judges</a></li>
   </ul>
</nav>


<?php 
//echo 'current_module = '.$current_module.'<br>';
//echo 'current_action = '.$current_action.'<br>';

/*List of Competitions*/
if($current_module == 'competitions' && $current_action == 'list_parent_competitions'){
	$competitions_data = $wpdb->get_results( "SELECT * FROM ".GEEK_DANCE_PARENT_COMPETITIONS_TABLE."  ORDER BY `id` DESC", ARRAY_A);
	?>
	<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=add_new_parent_competition">Add New Parent Competition</a>

	<table style="width:100%;">
	  <tr>
	    <th>Title</th>
	    <th>Final Date</th>
	    <th>Action</th>
	  </tr>
	
		<?php	
			if($competitions_data){
				foreach ($competitions_data as $key => $value) {
						$competition_id		=  $value['id'];
						$title 				=  $value['title'];
						$evaluation_form 	=  $value['evaluation_form'];
						$type 				=  $value['type'];
						$status 			=  $value['status'];
						$final_date 		=  $value['final_date'];
						?>
							<tr>
							    <td><?php echo $title; ?></td>
							    <td><?php echo $final_date; ?></td>
							    <td>
							    	<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=edit_parent_competition&id=<?php echo $competition_id; ?>">Edit</a>
							    	 / 
							    	<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=list_competitions&id=<?php echo $competition_id; ?>">View Sub Competition</a>

							    	/ 
							    	<a href="#">Add New Sub Competition</a>
							    </td>
						  	</tr>
						<?php
					}	
			}
		?>
	</table>

<?php }else if ($current_module == 'competitions' && $current_action == 'list_competitions'){
	
	/*List of Sub Competitions*/
	$competitions_data = $wpdb->get_results( "SELECT * FROM ".GEEK_DANCE_COMPETITIONS_TABLE."  ORDER BY `id` DESC", ARRAY_A);
	?>
	<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=add_new_competition">Add New Sub Competition</a>

	<table style="width:100%;">
	  <tr>
	    <th>Title</th>
	    <th>Evaluation Form</th>
	    <th>Type</th>
	    <th>Final Date</th>
	    <th>Action</th>
	  </tr>
		<?php	
			if($competitions_data){
				foreach ($competitions_data as $key => $value) {
						$competition_id		=  $value['id'];
						$title 				=  $value['title'];
						$evaluation_form 	=  $value['evaluation_form'];
						$type 				=  $value['type'];
						$status 			=  $value['status'];
						$final_date 		=  $value['final_date'];
						?>
							<tr>
							    <td><?php echo $title; ?></td>
							    <td><?php echo $evaluation_form; ?></td>
							    <td><?php echo $type; ?></td>
							    <td><?php echo $final_date; ?></td>
							    <td>
							    	<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=edit_competition&id=<?php echo $competition_id; ?>">Edit</a>
							    	 / 
							    	<a href="#">View Finalist</a>
							    </td>
						  	</tr>
						<?php
					}	
			}
		?>
	</table>

<?php } else if($current_module == 'competitions' && ($current_action == 'edit_parent_competition' ||  $current_action == 'add_new_parent_competition')){

	/*Add and Edit Parent Competition*/
	include_once GEEK_DANCE_PLUGIN_DIR_PATH.'includes/shortcodes/geek_dance_parent_competitions.php';

}else if($current_module == 'competitions' && ($current_action == 'edit_competition' ||  $current_action == 'add_new_competition')){
	
	/*Add and Edit Competition*/
	include_once GEEK_DANCE_PLUGIN_DIR_PATH.'includes/shortcodes/geek_dance_competitions.php';

} 
?>	
