<?php
/*Add Competition Start*/
if ( $_POST['competition_action'] == 'add' && wp_verify_nonce($_POST['geek_dance_register_competition_nonce'], 'geek-dance-register-competition-nonce')) {
	global $wpdb;
	// echo "<pre>";
	// print_r($_POST['competition']);
	// echo "</pre>";

	$competition_data 	= $_POST['competition'];

	$title 			= isset($competition_data['title']) ? $competition_data['title'] : '';
	$evaluation_form = isset($competition_data['evaluation_form']) ? $competition_data['evaluation_form'] : '';
	$type = isset($competition_data['type']) ? $competition_data['type'] : '';
	$status = isset($competition_data['status']) ? $competition_data['status'] : '0';
	$final_date = isset($competition_data['final_date']) ? $competition_data['final_date'] : '';

	/*Evaluation Form Logic*/
	
	if($title == ""){
		geek_dance_errors()->add('competition_name_unavailable', __('Name should not be empty'));
	}
	
	if($final_date == ""){
		geek_dance_errors()->add('competition_age_unavailable', __('Final date should not be empty'));
	}
	
	/*Check whether record exists or not*/
	/*
		$record_found = $wpdb->get_row( "SELECT COUNT(*) as count FROM ".GEEK_DANCE_competitionS_TABLE." WHERE competition_id = $competition_id AND email = '".$email."'", ARRAY_A );
		if($record_found['count'] > 0){
			geek_dance_errors()->add('competition_exists', __('Record with unique details already exists'));
		}
	*/

	$errors = geek_dance_errors()->get_error_messages();

	// only create the user in if there are no errors
	if(empty($errors)) {
			$data = array(
			'title'    			=>  $title,
			'evaluation_form'   =>  $evaluation_form,
			'type'  			=>  $type,
			'status'    		=>  $status,
			'final_date'    	=>  $final_date,
			'created_date'    	=>  date("Y-m-d H:i:s"),
		);

		$wpdb->insert(GEEK_DANCE_COMPETITIONS_TABLE, $data);
		//echo $id = $wpdb->insert_id;  
		//echo $wpdb->last_query;
	}
}		
/*Add Competition End*/
?>