<?php
/*Add Edit Parent Competition Start*/
if ( ($_POST['parent_competition_action'] == 'add' || $_POST['parent_competition_action'] == 'edit') && wp_verify_nonce($_POST['geek_dance_register_parent_competition_nonce'], 'geek-dance-register-parent-competition-nonce')) {
	global $wpdb;
	$parent_competition_data 	= $_POST['parent_competition'];
	$action 					= $_POST['parent_competition_action'];
	$title 			= isset($parent_competition_data['title']) ? $parent_competition_data['title'] : '';
	$status 		= isset($parent_competition_data['status']) ? $parent_competition_data['status'] : '0';
	$final_date 	= isset($parent_competition_data['final_date']) ? $parent_competition_data['final_date'] : '';

	/*Evaluation Form Logic*/
	
	if($title == ""){
		geek_dance_errors()->add('parent_competition_name_unavailable', __('Name should not be empty'));
	}
	
	if($final_date == ""){
		geek_dance_errors()->add('parent_competition_age_unavailable', __('Final date should not be empty'));
	}
		
	$errors = geek_dance_errors()->get_error_messages();

	// only create the user in if there are no errors
	if(empty($errors)) {
			$data = array(
			'title'    			=>  $title,
			'status'    		=>  $status,
			'final_date'    	=>  $final_date,
			'created_date'    	=>  date("Y-m-d H:i:s"),
		);

		if($action == 'add'){
			
			$wpdb->insert(GEEK_DANCE_PARENT_COMPETITIONS_TABLE, $data);	

		}else if($action == 'edit'){
			
			$id 	= isset($parent_competition_data['id']) ? $parent_competition_data['id'] : '';
			unset($data['created_date']);
			$result = $wpdb->update(GEEK_DANCE_PARENT_COMPETITIONS_TABLE, 
									$data, 
									array('id' => $id), 
									array('%s', '%d', '%s'),
									 array('%d')
									);

			if($result > 0){
				echo "Successfully Updated";
			}
		}
	}
}		

?>