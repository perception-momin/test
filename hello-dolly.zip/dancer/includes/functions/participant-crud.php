<?php
/*Add Participant Start*/
if ( $_POST['participant_action'] == 'add' && wp_verify_nonce($_POST['geek_dance_register_participant_nonce'], 'geek-dance-register-participant-nonce')) {
	global $wpdb;
	echo "<pre>";
	print_r($_POST['participant']);
	echo "</pre>";

	$participant_data 	= $_POST['participant'];

	$title 			= isset($participant_data['title']) ? $participant_data['title'] : '';
	$name 			= isset($participant_data['name']) ? $participant_data['name'] : '';
	$email 			= isset($participant_data['email']) ? $participant_data['email'] : '';
	$age 			= isset($participant_data['age']) ? $participant_data['age'] : '';
	$entry_no 		= isset($participant_data['entry_no']) ? $participant_data['entry_no'] : '';
	$cda_code 		= isset($participant_data['cda_code']) ? $participant_data['cda_code'] : '0';
	$cda 			= isset($participant_data['cda']) ? $participant_data['cda'] : '0';

	/*Evaluation Form Logic*/
	$evaluation_form = isset($participant_data['evaluation_form']) ? $participant_data['evaluation_form'] : array();
	$haystack 	 	= array('contempory','classical' );	
	if(!empty($evaluation_form) && count(array_intersect($haystack, $evaluation_form)) == count($evaluation_form)){
    	$evaluation_form_value = 2;
	}else if(in_array('contempory', $evaluation_form)){
		$evaluation_form_value = 1;
	}else if(in_array('classical', $evaluation_form)){
		$evaluation_form_value = 0;
	}else{
		geek_dance_errors()->add('evaluation_form_empty', __('Evaluation Form should not be empty'));
	}
	
	$competition_id = 1;

	if($name == ""){
		geek_dance_errors()->add('participant_name_unavailable', __('Name should not be empty'));
	}

	if($email == ""){
		geek_dance_errors()->add('participant_email_unavailable', __('Email should not be empty'));
	}

	if($age == ""){
		geek_dance_errors()->add('participant_age_unavailable', __('Age should not be empty'));
	}

	if($entry_no == ""){
		geek_dance_errors()->add('participant_entry_no_unavailable', __('Entry No. should not be empty'));
	}

	/*Check whether record exists or not*/
	$record_found = $wpdb->get_row( "SELECT COUNT(*) as count FROM ".GEEK_DANCE_PARTICIPANTS_TABLE." WHERE competition_id = $competition_id AND email = '".$email."'", ARRAY_A );
	if($record_found['count'] > 0){
		geek_dance_errors()->add('participant_exists', __('Record with unique details already exists'));
	}

	$errors = geek_dance_errors()->get_error_messages();

	// only create the user in if there are no errors
	if(empty($errors)) {
			$data = array(
			'competition_id'  	=>  $competition_id,
			'name'    			=>  $name,
			'email'    			=>  $email,
			'age'    			=>  $age,
			'entry_no'    		=>  $entry_no,
			'cda'    			=>  $cda,
			'cda_code'  		=>  $cda_code,
			'evaluation_form'   =>  $evaluation_form_value,
			'title'    			=>  $title,
			'photo_name'   		=>  'admin',
			'created_date'    	=>  date("Y-m-d H:i:s"),
		);

		//$wpdb->insert(GEEK_DANCE_PARTICIPANTS_TABLE, $data);
		//echo $id = $wpdb->insert_id;  
		//echo $wpdb->last_query;
	}
}		
/*Add Participant End*/
?>