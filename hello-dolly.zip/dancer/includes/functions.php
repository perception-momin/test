<?php 
add_action( 'admin_init', 'redirect_non_admin_users' );
function redirect_non_admin_users() {
	if ( ! current_user_can( 'manage_options' ) && ('/wp-admin/admin-ajax.php' != $_SERVER['PHP_SELF']) ) {
	wp_redirect( home_url() );
	exit;
	}
}


/* Add roles. Competition Maanger, Judges*/ 
add_role( 'geek_dance_manager', 'Competition Manager', array(
													'read' => true
												) 
		); 

add_role( 'geek_dance_judge', 'Judge', array(
										'read' => true
									) 
		);


include_once 'functions/login-register.php';
include_once 'functions/participant-crud.php';
include_once 'functions/Competition-crud.php';
include_once 'functions/parent-Competition-crud.php';
?>