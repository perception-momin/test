<?php 
function geek_dance_login_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	if(!is_user_logged_in()) {
 		global $geek_dance_load_css;
 		// set this to true so the CSS is loaded
		$geek_dance_load_css = true;
 		$output = geek_dance_login_form_fields();
	} else {
		// could show some logged in user info here
		// $output = 'user info here';
	}
	return $output;
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_login', 'geek_dance_login_func_callback' );



function geek_dance_registration_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	// only show the registration form to non-logged-in members
	if(!is_user_logged_in()) {
 		global $geek_dance_load_css;
 		// set this to true so the CSS is loaded
		$geek_dance_load_css = true;
 		// check to make sure user registration is enabled
		$registration_enabled = get_option('users_can_register');
 		// only show the registration form if allowed
		if($registration_enabled) {
			$output = geek_dance_registration_form_fields();
		} else {
			$output = __('User registration is not enabled');
		}
		return $output;
	}
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_registration', 'geek_dance_registration_func_callback' );



function geek_dance_participants_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'shortcodes/geek_dance_participants.php';
	return ob_get_clean();
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_participants', 'geek_dance_participants_func_callback' );



function geek_dance_competitions_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'shortcodes/geek_dance_competitions.php';
	return ob_get_clean();
}
add_shortcode( 'geek_dance_competitions', 'geek_dance_competitions_func_callback' );

function geek_dance_main_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'geek_dance_main.php';
	return ob_get_clean();
}
add_shortcode( 'geek_dance_main', 'geek_dance_main_func_callback' );
?>