<?php 
   $current_action; 
   $parent_competition_id;
   $data = 'edit_parent_competition';
   $data = 'add_new_parent_competition';
   $parent_competition_action = $title = $final_date = $status = "";
   $show_form = false;

   if($current_action == 'add_new_parent_competition'){
         $parent_competition_action  = "add";
         $show_form           = true;
   }elseif ($current_action == 'edit_parent_competition' && !empty($parent_competition_id) ){
         $parent_competition_action = "edit";
         $show_form          = true;
         $record_found = $wpdb->get_row( "SELECT *  FROM ".GEEK_DANCE_PARENT_COMPETITIONS_TABLE." WHERE id = $parent_competition_id", ARRAY_A );
         
         if(empty($record_found)){
            geek_dance_errors()->add('record_not_exists', __('No data found for the given parent competition id'));
            $show_form          = false;
         }

         $title            = isset($record_found['title']) ? $record_found['title'] : '';
         $final_date       = isset($record_found['final_date']) ? $record_found['final_date'] : '';
         $final_date       = explode(' ', $final_date);
         $status           = isset($record_found['status']) ? $record_found['status'] : '';
   }
?>

<a href="<?php echo $geek_dance_main_url ?>?module=competitions">View All Parent Competitions</a>
<div class="geek_dance_form">
	<?php geek_dance_show_error_messages(); ?>

   <?php if($show_form){ ?>
      <div class="geek_dance_form-heading">Add Parent Competition</div>
      <form action="" method="post" enctype="multipart/form-data">
         
         <input type="hidden" name="parent_competition_action" value="<?php echo $parent_competition_action; ?>">
         <input type="hidden" name="parent_competition[id]" value="<?php echo $parent_competition_id; ?>">

         <label for="title">
               <span>Title <span class="required">*</span></span>
               <input type="text" required class="input-field" name="parent_competition[title]"  value="<?php echo $title; ?>" />
         </label>
        
         <label for="final_date">
               <span>Final Date</span>
               <input type="date" class="input-field" name="parent_competition[final_date]" value="<?php echo $final_date['0']; ?>" />
         </label>

         <label for="status">
            <span>Status</span>
            <select name="parent_competition[status]" class="select-field">
               <option value="1" <?php selected( $status, '1' ); ?>>Active</option>
               <option value="0" <?php selected( $status, '0' ); ?>>InActive</option>
            </select>
         </label>
               
         <input type="hidden" name="geek_dance_register_parent_competition_nonce" value="<?php echo wp_create_nonce('geek-dance-register-parent-competition-nonce'); ?>"/>
   					
         <label><span> </span><input type="submit" value="Submit" /></label>
      </form>
   <?php } ?>   
</div>