<?php 
   $current_action; 
   $competition_id;
   $data = 'edit_competition';
   $data = 'add_new_competition';
   $competition_action = $title = $evaluation_form = $type = $final_date = $status = "";
   $show_form = false;

   if($current_action == 'add_new_competition'){
         $competition_action  = "add";
         $show_form           = true;
   }elseif ($current_action == 'edit_competition' && !empty($competition_id) ){
         $competition_action = "edit";
         $show_form          = true;
         $record_found = $wpdb->get_row( "SELECT *  FROM ".GEEK_DANCE_COMPETITIONS_TABLE." WHERE id = $competition_id", ARRAY_A );
         print_r($record_found);

         if(empty($record_found)){
            geek_dance_errors()->add('record_not_exists', __('No data found for the given competition id'));
            $show_form          = false;
         }

         $title            = isset($record_found['title']) ? $record_found['title'] : '';
         $evaluation_form  = isset($record_found['evaluation_form']) ? $record_found['evaluation_form'] : '';
         $type             = isset($record_found['type']) ? $record_found['type'] : '';
         $final_date       = isset($record_found['final_date']) ? $record_found['final_date'] : '';
         $final_date       = explode(' ', $final_date);
         $status           = isset($record_found['status']) ? $record_found['status'] : '';
   }
?>

<a href="<?php echo $geek_dance_main_url ?>?module=competitions&action=list_competitions">View All Competitions</a>
<div class="geek_dance_form">
	<?php geek_dance_show_error_messages(); ?>

   <?php if($show_form){ ?>
      <div class="geek_dance_form-heading">Add Competition</div>
      <form action="" method="post" enctype="multipart/form-data">
         
         <input type="hidden" name="competition_action" value="<?php echo $competition_action; ?>">

         <label for="title">
               <span>Title <span class="required">*</span></span>
               <input type="text" required class="input-field" name="competition[title]"  value="<?php echo $title; ?>" />
         </label>

         <label for="evaluation_form">
            <span>Evaluation Form</span>
            <select name="competition[evaluation_form]" class="select-field">
               <option value="Contempory" <?php selected( $evaluation_form, 'Contempory' ); ?>>Contempory</option>
               <option value="Classical" <?php selected( $evaluation_form, 'Classical' ); ?>>Classical</option>
            </select>
         </label>

         <label for="type">
            <span>Type</span>
            <select name="competition[type]" class="select-field">
               <option value="Senior" <?php selected( $type, 'Senior' ); ?>>Senior</option>
               <option value="Junior" <?php selected( $type, 'Junior' ); ?>>Junior</option>
            </select>
         </label>

         <label for="final_date">
               <span>Final Date</span>
               <input type="date" class="input-field" name="competition[final_date]" value="<?php echo $final_date['0']; ?>" />
         </label>

         <label for="status">
            <span>Status</span>
            <select name="competition[status]" class="select-field">
               <option value="1" <?php selected( $status, '1' ); ?>>Active</option>
               <option value="0" <?php selected( $status, '0' ); ?>>InActive</option>
            </select>
         </label>
               
         <input type="hidden" name="geek_dance_register_competition_nonce" value="<?php echo wp_create_nonce('geek-dance-register-competition-nonce'); ?>"/>
   					
         <label><span> </span><input type="submit" value="Submit" /></label>
      </form>
   <?php } ?>   
</div>