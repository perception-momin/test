<div class="geek_dance_form">
	<?php geek_dance_show_error_messages(); ?>

   <div class="geek_dance_form-heading">Add Participant</div>
   <form action="" method="post" enctype="multipart/form-data">
      
      <input type="hidden" name="participant_action" value="add">

      <label for="name">
      	<span>Name <span class="required">*</span></span>
      	<input type="text" required class="input-field" name="participant[name]" />
      </label>
      
      <label for="email">
      	<span>Email <span class="required">*</span></span>
      	<input type="email" required class="input-field" name="participant[email]" />
      </label>
      
      <label for="age">
      	<span>Age</span>
      	<input type="number" class="input-field" name="participant[age]" />
      </label>
      
      <label for="entry_no">
      	<span>Entry Number</span>
      	<input type="number" class="input-field" name="participant[entry_no]" />
      </label>
      
      <label for="cda">
      	<span>CDA</span>
      	<input type="checkbox" class="input-checkbox" name="participant[cda]" value="1" />
      </label>

      <label for="cda_code">
      	<span>CDA Code</span>
      	<input type="text" class="input-field" name="participant[cda_code]" />
      </label>

      <label for="evaluation_form">
      	<span>Evaluation Form</span>
      	<input type="checkbox" class="input-checkbox" name="participant[evaluation_form][]" value="contempory" /> Contempory
      	<input type="checkbox" class="input-checkbox" name="participant[evaluation_form][]" value="classical" /> Classical
      </label>

      <label for="title">
      	<span>Title <span class="required">*</span></span>
      	<input type="text" required class="input-field" name="participant[title]" />
      </label>

      <label for="image">
      	<span>Image</span>
      	<input type="file" class="input-field" name="participant[image]" />
      </label>
     
      <input type="hidden" name="geek_dance_register_participant_nonce" value="<?php echo wp_create_nonce('geek-dance-register-participant-nonce'); ?>"/>
					
      <label><span> </span><input type="submit" value="Submit" /></label>
   </form>
</div>