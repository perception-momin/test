<?php 
function geek_dance_login_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'scw_chat_read_message.php';
	return ob_get_clean();
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_login', 'geek_dance_login_func_callback' );


function geek_dance_registration_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'scw_chat_read_message.php';
	return ob_get_clean();
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_registration', 'geek_dance_registration_func_callback' );


function geek_dance_participants_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'scw_chat_read_message.php';
	return ob_get_clean();
	//return "foo = {$a['foo']}";
}
add_shortcode( 'geek_dance_participants', 'geek_dance_participants_func_callback' );



function geek_dance_participants_func_callback( $atts ) {
	$a = shortcode_atts( array(
		'foo' => 'something',
		'bar' => 'something else',
	), $atts );

	ob_start();
	include_once 'scw_chat_read_message.php';
	return ob_get_clean();
}
add_shortcode( 'geek_dance_competitions', 'geek_dance_competitions_func_callback' );

?>