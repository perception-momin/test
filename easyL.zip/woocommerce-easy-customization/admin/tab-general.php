<?php
	/**
	 * PRIMARY OPTIONS TAB - GENERAL OPTIONS	
	 * Registers main options page menu item and form.
	 */
	$args = array(
		'id'           => 'wec_general_options_page',
		'title'        => 'Woo Easy Customize',
		'object_types' => array( 'options-page' ),
		'option_key'   => 'wec_general_options',
		'tab_group'    => 'wec_general_options',
		'tab_title'    => 'General',
	);

	// 'tab_group' property is supported in > 2.4.0.
	if ( version_compare( CMB2_VERSION, '2.4.0' ) ) {
		$args['display_cb'] = 'wec_options_display_with_tabs';
	}
	$general_options = new_cmb2_box( $args );

	include_once('cart-customization-cmb2-options/general/woo-hide-mini-cart-widget.php');
	include_once('cart-customization-cmb2-options/general/woo-show-checkout-on-cart-empty.php');
	include_once('cart-customization-cmb2-options/general/woo-merge-cart-checkout-page.php');
	include_once('cart-customization-cmb2-options/general/woo-change-continue-shopping-link.php');

	/*
	$group_field_id = $general_options->add_field( array(
		'id'          => 'wec_group_titles_demo',
		'type'        => 'group',
		'description' => __( 'Generates reusable form entries', 'cmb2' ),
		'options'     => array(
			'group_title'    => __( 'Entry {#}', 'cmb2' ), // {#} gets replaced by row number
			'add_button'     => __( 'Add Another Entry', 'cmb2' ),
			'remove_button'  => __( 'Remove Entry', 'cmb2' ),
			'sortable'       => true, // beta
		),
		'after_group' => 'wec_add_js_for_repeatable_titles',
	) );

	$general_options->add_group_field( $group_field_id, array(
		'name' => 'Title',
		'id'   => 'title',
		'type' => 'text',
	) );
	$general_options->add_group_field( $group_field_id, array(
		'name' => 'Description',
		'id'   => 'description',
		'type' => 'textarea_small',
	) );
	*/
?>