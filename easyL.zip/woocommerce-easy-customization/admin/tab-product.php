<?php
	/**
	 * SECONDARY OPTIONS TAB - PRODUCT OPTIONS	
	 * Registers secondary options page, and set main item as parent.
	 */
	$args = array(
		'id'           => 'wec_product_options_page',
		'menu_title'   => 'Product Options',
		'object_types' => array( 'options-page' ),
		'option_key'   => 'wec_product_options',
		'parent_slug'  => 'wec_general_options',
		'tab_group'    => 'wec_general_options',
		'tab_title'    => 'Product',
	);

	// 'tab_group' property is supported in > 2.4.0.
	if ( version_compare( CMB2_VERSION, '2.4.0' ) ) {
		$args['display_cb'] = 'wec_options_display_with_tabs';
	}
	$product_options = new_cmb2_box( $args );
	
	include_once('cart-customization-cmb2-options/product/woo-change-product-price-based-on-quantity-in-cart.php');
	include_once('cart-customization-cmb2-options/product/woo-exclude-hidden-product-from-mini-cart-counter.php');
	include_once('cart-customization-cmb2-options/product/woo-add-product-on-visiting-specific-page.php');
?>	