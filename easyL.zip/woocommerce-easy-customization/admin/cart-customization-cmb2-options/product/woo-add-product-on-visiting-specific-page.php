<?php
$product_options->add_field( array(
	'name' => 'Automatic Add Product in Cart Section',
	'desc' => 'would you like make your website add product to cart automatically, on visiting the specific WordPress page',
	'type' => 'title',
	'id'   => 'wec_automatic_add_product_in_cart'
) );

$product_options->add_field( array(
	'name' => 'Enable Add Product to Cart',
	'desc' => 'Check this to enable feature',
	'id'   => 'wec_add_product_on_visiting_specific_page',
	'type' => 'checkbox',
) );

$product_options->add_field( array(
	'name' => 'Select Product',
	'desc' => 'Select which product need to be added to the cart automatically',
	'id'   => 'wec_automatic_add_product_in_car_product_id',
	'type'             => 'select',
	'show_option_none' => true,
	'options'          => wec_get_product_list()
) );

$product_options->add_field( array(
	'name' => 'Select Page',
	'desc' => 'Select a page on whose visit above product will be added to cart',
	'id'   => 'wec_automatic_add_product_in_car_page_id',
	'type'             => 'select',
	'show_option_none' => true,
	'options'          => wec_get_page_list()
) );
?>	