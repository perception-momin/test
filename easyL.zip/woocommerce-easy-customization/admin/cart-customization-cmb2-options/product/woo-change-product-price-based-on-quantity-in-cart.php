<?php
$product_options->add_field( array(
	'name' => 'Bulk (Dynamic) Pricing Section',
	'desc' => 'Setting for the Product Price Customization based on Quantity in a Cart',
	'type' => 'title',
	'id'   => 'wec_product_price_customization_section'
) );

$product_options->add_field( array(
	'name' => 'Enable Dynamic Pricing',
	'desc' => 'Change Product Price Based on Quantity Added to Cart (Bulk Pricing)',
	'id'   => 'wec_change_product_price_based_on_quantity_in_cart',
	'type' => 'checkbox',
) );


/*Repeater Section To Add Threshold and Discount*/
$group_field_id = $product_options->add_field( array(
	'id'          => 'wec_group_bulk_pricing_setting',
	'type'        => 'group',
	'description' => __( 'Add Dynamic Pricing Label, Threshold and Discount. NOTE : only add first two repeater group.', 'cmb2' ),
	'options'     => array(
		'group_title'    => __( 'Dynamic Pricing Rule {#}', 'cmb2' ), // {#} gets replaced by row number
		'add_button'     => __( 'Add Rule', 'cmb2' ),
		'remove_button'  => __( 'Remove Rule', 'cmb2' ),
		//'sortable'       => true, // beta
	),
) );

$product_options->add_group_field( $group_field_id, array(
	'name' => __( 'Threshold Number', 'theme-domain' ),
	'desc' => __( 'If product Quantity exceed this Threshold number then only related discount will be applied on the cart page. i.e. If Threshold Number is 100 and the Quantity of specific product is greater then 100 then it will reduce unit price by given percentage', 'msft-newscenter' ),
	'id'   => 'wec_group_threshold_number',
	'type' => 'text',
	'attributes' => array(
		'type' => 'number',
		'pattern' => '\d*',
	),
	'sanitization_cb' => 'absint',
        'escape_cb'       => 'absint',
) );

$product_options->add_group_field( $group_field_id, array(
	'name' => __( 'Discount', 'theme-domain' ),
	'desc' => __( 'This number will be treated as percentage discount. If you enter 10 then it will be 10% reduce in unit price if the product reached Threshold', 'msft-newscenter' ),
	'id'   => 'wec_group_discount',
	'type' => 'text',
	'attributes' => array(
		'type' => 'number',
		'pattern' => '\d*',
	),
	'sanitization_cb' => 'absint',
        'escape_cb'       => 'absint',
) );


?>