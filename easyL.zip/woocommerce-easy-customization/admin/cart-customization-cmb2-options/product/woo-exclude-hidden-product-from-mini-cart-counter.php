<?php
$product_options->add_field( array(
	'name' => 'Hidden Product Section',
	'desc' => 'As name suggest, Hidden product must be hidden from the possible pages like cart, checkout , order email. This setting will help in hiding hidden product for the below given options by enable the same',
	'type' => 'title',
	'id'   => 'wec_hide_hidden_product_section'
) );

$product_options->add_field( array(
	'name' => 'Hide from mini-cart counter',
	'desc' => 'Check this to Hide Hidden Product From the Mini cart Counter',
	'id'   => 'wec_exclude_hidden_product_from_mini_cart_counter',
	'type' => 'checkbox',
) );

$product_options->add_field( array(
	'name' => 'Hide from Cart',
	'desc' => 'Check this to Hide Hidden Product From the Cart Page',
	'id'   => 'wec_exclude_hidden_product_from_cart_item',
	'type' => 'checkbox',
) );

$product_options->add_field( array(
	'name' => 'Hide from Widget Cart',
	'desc' => 'Check this to Hide Hidden Product From the Widget Cart',
	'id'   => 'wec_exclude_hidden_product_from_widget_cart',
	'type' => 'checkbox',
) );

$product_options->add_field( array(
	'name' => 'Hide from Checkout',
	'desc' => 'Check this to Hide Hidden Product From the Checkout',
	'id'   => 'wec_exclude_hidden_product_from_checkout',
	'type' => 'checkbox',
) );

$product_options->add_field( array(
	'name' => 'Hide from Order Email',
	'desc' => 'Check this to Hide Hidden Product From the Order Email',
	'id'   => 'wec_exclude_hidden_product_from_order_email',
	'type' => 'checkbox',
) );

?>