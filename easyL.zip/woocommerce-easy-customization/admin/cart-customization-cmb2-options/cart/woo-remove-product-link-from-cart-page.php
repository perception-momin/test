<?php
	$cart_options->add_field( array(
		'name' => 'Remove product link from Cart Page',
		'desc' => 'Would you like to remove Product Link over Product Title from the Cart Page?',
		'type' => 'checkbox',
		'id'   => 'wec_remove_product_link_from_cart_page'
	) );
?>