<?php
$cart_options->add_field( array(
	'name' => 'Cart Sort Section',
	'desc' => 'You need to enable "Sort Cart Items Alphabetically"  in order to sort your cart alphabetically first.',
	'type' => 'title',
	'id'   => 'wec_product_price_customization_section'
) );

$cart_options->add_field( array(
	'name' => 'Split Cart Table Alphabetically',
	'desc' => 'Split Cart by A>Z i.e Display Letter Above Each Section',
	'type' => 'checkbox',
	'id'   => 'wec_split_cart_table_alphabetically'
) );

$cart_options->add_field( array(
	'name' => 'Sort Cart Items Alphabetically',
	'desc' => 'Sort products based on their title, from A to Z',
	'id'   => 'wec_sort_cart_item_alphabetically',
	'type' => 'checkbox',
) );
?>