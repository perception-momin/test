<?php 
$general_options->add_field( array(
	'name' => 'Show Checkout on Empty Cart',
	'desc' => 'Would you like to avoid checkout redirect to empty cart?',
	'id'   => 'wec_show_checkout_on_cart_empty',
	'type' => 'checkbox',
) );
?>