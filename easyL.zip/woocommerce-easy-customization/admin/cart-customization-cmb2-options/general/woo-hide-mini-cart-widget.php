<?php
$general_options->add_field( array(
	'name' => 'Hide Mini Cart Widget',
	'desc' => 'Would you like to disable Mini Cart Widget which is visible when you hover over cart icon on the top right of your store?',
	'id'   => 'wec_hide_mini_cart_widget',
	'type' => 'checkbox',
) );
?>	