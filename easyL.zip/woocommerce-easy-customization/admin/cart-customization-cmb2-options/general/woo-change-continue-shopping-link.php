<?php

$general_options->add_field( array(
	'name' => 'Shopping Link Section',
	'desc' => 'This is a title description',
	'type' => 'title',
	'id'   => 'wec_shopping_link_section'
) );

$general_options->add_field( array(
	'name' => 'Enable Continue Shopping Link',
	'desc' => 'Would you like to change the continue Shopping link visible on cart page?',
	'id'   => 'wec_change_continue_shopping_link',
	'type' => 'checkbox',
) );

$general_options->add_field( array(
		'name'             => esc_html__( 'Select page', 'cmb2' ),
		'desc'             => esc_html__( 'Select page to use as shopping page link', 'cmb2' ),
		'id'               => 'wec_change_continue_shopping_link_url',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => wec_get_page_list()
	) );
?>