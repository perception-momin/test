<?php 
ob_start();
?>
	This setting required some manual setup.Please enable checkbox and follow steps to active this setting.
	<div>Step 1 : Enable 'Merge Checkout and Cart' checkbox</div>
	<div>Step 2 : Unset cart page in WooCommerce settings under  WooCommerce > Settings > Advanced) – simply click on the little “x” and “Save Changes”.</div>
	<div>Step 3 : Delete Cart Page</div>
	<div>Step 4 : If you don’t want to show an empty Checkout page if users access it directly or when the cart table is emptied, enable 'Enable Empty Checkout Redirect' and select the page where to redirec. (OPTIONAL)</div>
<?php

$description = ob_get_clean();

$general_options->add_field( array(
	'name' => 'Merge Cart Checkout Section',
	'desc' => $description,
	'type' => 'title',
	'id'   => 'wec_merge_cart_checkout_section'
) );

$general_options->add_field( array(
	'name' => 'Merge Checkout and Cart',
	'desc' => 'Would you like merge Cart Page and Checkout Page?',
	'id'   => 'wec_merge_cart_checkout_page',
	'type' => 'checkbox',
) );

$general_options->add_field( array(
	'name' => 'Enable Empty Checkout Redirect',
	'desc' => 'Would you like Enable Empty Checkout Redirect?',
	'id'   => 'wec_enable_empty_checkout_redirect',
	'type' => 'checkbox',
) );

$general_options->add_field( array(
		'name'             => esc_html__( 'Select page', 'cmb2' ),
		'desc'             => esc_html__( 'Select page where to redirect on empty checkout, if Enable Empty Checkout Redirect is enable', 'cmb2' ),
		'id'               => 'wec_empty_checkout_redirect_url',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => wec_get_page_list()
	) );
?>