<?php
$checkout_options->add_field( array(
	'name' => 'Checkout Coupon Section',
	'desc' => 'You need to enable "Sort Cart Items Alphabetically"  in order to sort your cart alphabetically first.',
	'type' => 'title',
	'id'   => 'wec_checkout_coupon_section'
) );

$checkout_options->add_field( array(
	'name' => 'Remove Coupon Form on Checkout Page',
	'type' => 'checkbox',
	'id'   => 'wec_remove_coupon_form_on_checkout_page'
) );

$checkout_options->add_field( array(
	'name' => 'Move Coupon Form on Checkout Page',
	'desc' => 'Enabling this option will move the Coupon Form below the checkout form',
	'type' => 'checkbox',
	'id'   => 'wec_move_coupon_form_on_checkout_page'
) );
?>