<?php
	/**
	 * FOURTH OPTIONS TAB - CART OPTIONS	
	 * Registers tertiary options page, and set main item as parent.
	 */
	$args = array(
		'id'           => 'wec_checkout_options_page',
		'menu_title'   => 'Checkout Options', // Use menu title, & not title to hide main h2.
		'object_types' => array( 'options-page' ),
		'option_key'   => 'wec_checkout_options',
		'parent_slug'  => 'wec_general_options',
		'tab_group'    => 'wec_general_options',
		'tab_title'    => 'Checkout',
	);
	// 'tab_group' property is supported in > 2.4.0.
	if ( version_compare( CMB2_VERSION, '2.4.0' ) ) {
		$args['display_cb'] = 'wec_options_display_with_tabs';
	}
	$checkout_options = new_cmb2_box( $args );
	
	include_once('cart-customization-cmb2-options/checkout/woo-remove-or-move-coupon-form.php');
	include_once('cart-customization-cmb2-options/checkout/woo-simplify-checkout-on-virtual-product.php');

?>