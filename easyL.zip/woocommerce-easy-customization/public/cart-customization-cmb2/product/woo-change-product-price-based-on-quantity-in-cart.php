<?php
	$wec_change_product_price_based_on_quantity_in_cart =  $wec_product_options['wec_change_product_price_based_on_quantity_in_cart'];
	
	

	if(isset($wec_change_product_price_based_on_quantity_in_cart) && 'on' == $wec_change_product_price_based_on_quantity_in_cart ){
		add_action( 'woocommerce_before_calculate_totals', 'wec_quantity_based_pricing', 9999 );
	}

	function wec_quantity_based_pricing( $cart ) {
		$wec_group_bulk_pricing_setting = wec_get_option('wec_product_options', 'wec_group_bulk_pricing_setting');
		
		// echo "<pre>";
		// print_r($wec_group_bulk_pricing_setting);
		// echo "</pre>";
		
	    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
	 
	    if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) return;
	 	
	 	$threshold1 	= 0;
	    $discount1 		= 0;
	    $threshold2 	= 0;
	    $discount2 		= 0;
	 	if( isset($wec_group_bulk_pricing_setting['0']['wec_group_threshold_number'])){
	 		$threshold1 = $wec_group_bulk_pricing_setting['0']['wec_group_threshold_number'];
	 	}

	 	if( isset($wec_group_bulk_pricing_setting['0']['wec_group_discount'])){
	 		$discount1 = $wec_group_bulk_pricing_setting['0']['wec_group_discount'] / 100;
	 	}

	 	if( isset($wec_group_bulk_pricing_setting['1']['wec_group_threshold_number'])){
	 		$threshold2 = $wec_group_bulk_pricing_setting['1']['wec_group_threshold_number'];
	 	}

	 	if( isset($wec_group_bulk_pricing_setting['1']['wec_group_discount'])){
	 		$discount2 = $wec_group_bulk_pricing_setting['1']['wec_group_discount']/100;
	 	}
	 	/*
		    $threshold1 = 101; // Change price if items > 100
		    $discount1 = 0.05; // Reduce unit price by 5%
		    $threshold2 = 1001; // Change price if items > 1000
		    $discount2 = 0.1; // Reduce unit price by 10%
	 	*/

	    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
	      $product_id = $cart_item['product_id'];
	      if ( $cart_item['quantity'] >= $threshold1 && $cart_item['quantity'] < $threshold2 ) {
	         $price = round( $cart_item['data']->get_price() * ( 1 - $discount1 ), 2 );
	         $cart_item['data']->set_price( $price );
	      } elseif ( $cart_item['quantity'] >= $threshold2 ) {
	         $price = round( $cart_item['data']->get_price() * ( 1 - $discount2 ), 2 );
	         $cart_item['data']->set_price( $price );
	      }    
	    }
	    
	 }
?>