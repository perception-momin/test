<?php
	$wec_add_product_on_visiting_specific_page =  $wec_product_options['wec_add_product_on_visiting_specific_page'];
	
	if(isset($wec_add_product_on_visiting_specific_page) && 'on' == $wec_add_product_on_visiting_specific_page ){
		add_action( 'wp', 'wec_add_product_to_cart_on_page_id_load' );
	}
	  
	function wec_add_product_to_cart_on_page_id_load() {
	   // product ID to add to cart
	   $product_id = wec_get_option('wec_product_options','wec_automatic_add_product_in_car_product_id');
	   $page_id  = wec_get_option('wec_product_options','wec_automatic_add_product_in_car_page_id');
	   // page ID to target         
	   if ( is_page( $page_id ) ) {    
	   	  //WC()->cart->empty_cart();
	      WC()->cart->add_to_cart( $product_id ); 
	   }
	}
?>