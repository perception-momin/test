<?php
	$wec_exclude_hidden_product_from_mini_cart_counter =  $wec_product_options['wec_exclude_hidden_product_from_mini_cart_counter'];
	$wec_exclude_hidden_product_from_cart_item = $wec_product_options['wec_exclude_hidden_product_from_cart_item'];
	$wec_exclude_hidden_product_from_widget_cart = $wec_product_options['wec_exclude_hidden_product_from_widget_cart'];
	$wec_exclude_hidden_product_from_checkout = $wec_product_options['wec_exclude_hidden_product_from_checkout'];
	$wec_exclude_hidden_product_from_order_email = $wec_product_options['wec_exclude_hidden_product_from_order_email'];
	

    if(isset($wec_exclude_hidden_product_from_mini_cart_counter) && 'on' == $wec_exclude_hidden_product_from_mini_cart_counter ){
		add_filter( 'woocommerce_cart_contents_count', 'wec_exclude_hidden_minicart_counter' );
	}

	if(isset($wec_exclude_hidden_product_from_cart_item) && 'on' == $wec_exclude_hidden_product_from_cart_item ){
		add_filter( 'woocommerce_cart_item_visible', 'wec_hide_hidden_product_from_cart' , 10, 3 );
	}

	if(isset($wec_exclude_hidden_product_from_widget_cart) && 'on' == $wec_exclude_hidden_product_from_widget_cart ){
		add_filter( 'woocommerce_widget_cart_item_visible', 'wec_hide_hidden_product_from_cart', 10, 3 );
	}

	if(isset($wec_exclude_hidden_product_from_checkout) && 'on' == $wec_exclude_hidden_product_from_checkout ){
		add_filter( 'woocommerce_checkout_cart_item_visible', 'wec_hide_hidden_product_from_cart', 10, 3 );
	}

	if(isset($wec_exclude_hidden_product_from_order_email) && 'on' == $wec_exclude_hidden_product_from_order_email ){
		add_filter( 'woocommerce_order_item_visible', 'wec_hide_hidden_product_from_order_woo', 10, 2 );
	}

 
	function wec_exclude_hidden_minicart_counter( $quantity ) {
	  $hidden = 0;
	  foreach( WC()->cart->get_cart() as $cart_item ) {
	    $product = $cart_item['data'];
	    if ( $product->get_catalog_visibility() == 'hidden' ) $hidden += $cart_item['quantity'];
	  }
	  $quantity -= $hidden;
	  return $quantity;
	}

	function wec_hide_hidden_product_from_cart( $visible, $cart_item, $cart_item_key ) {
	   $product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
	   if ( $product->get_catalog_visibility() == 'hidden' ) {
	        $visible = false;
	    }
	    return $visible;
	}
   
	function wec_hide_hidden_product_from_order_woo( $visible, $order_item ) {
	   $product = $order_item->get_product();
	   if ( $product->get_catalog_visibility() == 'hidden' ) {
	        $visible = false;
	    }
	    return $visible;
	}
?>