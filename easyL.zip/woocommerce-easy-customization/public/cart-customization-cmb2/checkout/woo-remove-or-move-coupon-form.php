<?php
	if(isset($wec_checkout_options['wec_move_coupon_form_on_checkout_page']) && 'on' == $wec_checkout_options['wec_move_coupon_form_on_checkout_page'] ){
			add_action( 'woocommerce_proceed_to_checkout', 'wec_display_coupon_form_below_proceed_checkout', 25 );
			add_action( 'wp_head', 'wec_hide_coupon_form' );
	}
	
	if(isset($wec_checkout_options['wec_remove_coupon_form_on_checkout_page']) && 'on' == $wec_checkout_options['wec_remove_coupon_form_on_checkout_page'] ){
			remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 100 );
	}

	function wec_display_coupon_form_below_proceed_checkout() {
	   ?> 
	      <form class="woocommerce-coupon-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
	         <?php if ( wc_coupons_enabled() ) { ?>
	            <div class="coupon under-proceed">
	               <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" style="width: 100%" /> 
	               <button type="submit" class="button" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>" style="width: 100%"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></button>
	            </div>
	         <?php } ?>
	      </form>
	   <?php
	}	

	function wec_hide_coupon_form() {
	   ?> 
	      <style type="text/css">
	      	/* Hide the default coupon form @ WooCommerce Cart table */
			/* I hate to use display:none but there is no other solution */
			 
			div.coupon:not(.under-proceed) { 
			display: none !important; 
			}
	      </style>
	   <?php
	}	
?>