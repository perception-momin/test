<?php

	$wec_merge_cart_checkout_page = $wec_general_options['wec_merge_cart_checkout_page'];
	$wec_enable_empty_checkout_redirect = $wec_general_options['wec_enable_empty_checkout_redirect'];
	$wec_empty_checkout_redirect_url = $wec_general_options['wec_empty_checkout_redirect_url'];

	if(isset($wec_merge_cart_checkout_page) && 'on' == $wec_merge_cart_checkout_page ){
		add_action( 'woocommerce_before_checkout_form', 'wec_cart_on_checkout_page_only', 5 );
 	}

 	if(isset($wec_enable_empty_checkout_redirect) && 'on' == $wec_enable_empty_checkout_redirect ){
		add_action( 'template_redirect', 'wec_redirect_empty_cart_checkout_to_page' );
 	}
 	
	function wec_cart_on_checkout_page_only() {
 		if ( is_wc_endpoint_url( 'order-received' ) ) return;
		echo do_shortcode('[woocommerce_cart]');
	}

	function wec_redirect_empty_cart_checkout_to_page() {

		$redirect_url = home_url();
		if(isset($wec_empty_checkout_redirect_url) && !empty($wec_empty_checkout_redirect_url)){
			$redirect_url = get_the_permalink($wec_empty_checkout_redirect_url);
		}
		
	    if ( is_cart() && is_checkout() && 0 == WC()->cart->get_cart_contents_count() && ! is_wc_endpoint_url( 'order-pay' ) && ! is_wc_endpoint_url( 'order-received' ) ) {
	   	   wp_safe_redirect( $redirect_url );
	       exit;
	    }
	}
?>	