<?php
	$wec_change_continue_shopping_link  = $wec_general_options['wec_change_continue_shopping_link '];
	$wec_change_continue_shopping_link_url  = $wec_general_options['wec_change_continue_shopping_link_url '];
	
	if(isset($wec_change_continue_shopping_link) && 'on' == $wec_change_continue_shopping_link ){
		add_filter( 'woocommerce_continue_shopping_redirect', 'wec_change_continue_shopping' );
	}

	function wec_change_continue_shopping() {
		$redirect_url = wc_get_page_permalink( 'shop' );
		if(isset($wec_change_continue_shopping_link_url) && !empty($wec_change_continue_shopping_link_url)){
			$redirect_url = get_the_permalink($wec_change_continue_shopping_link_url);
		}
		return $redirect_url;	
	}
?>	