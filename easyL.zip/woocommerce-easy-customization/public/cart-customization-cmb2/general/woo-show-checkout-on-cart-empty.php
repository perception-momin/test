<?php
	if(isset($wec_general_options['wec_show_checkout_on_cart_empty']) && 'on' == $wec_general_options['wec_show_checkout_on_cart_empty'] ){
		add_filter( 'woocommerce_checkout_redirect_empty_cart', '__return_false' );
		add_filter( 'woocommerce_checkout_update_order_review_expired', '__return_false' );
	}
?>	
