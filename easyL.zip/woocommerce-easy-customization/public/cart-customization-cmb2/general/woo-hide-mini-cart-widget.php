<?php
	if(isset($wec_general_options['wec_hide_mini_cart_widget']) && 'on' == $wec_general_options['wec_hide_mini_cart_widget'] ){
		add_filter( 'woocommerce_widget_cart_is_hidden', '__return_true' );
	}
?>	