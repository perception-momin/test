<?php
	if(isset($wec_cart_options['wec_remove_product_link_from_cart_page']) && 'on' == $wec_cart_options['wec_remove_product_link_from_cart_page'] ){
			add_filter( 'woocommerce_cart_item_permalink', '__return_null' );
	}
?>