<?php
	/*
		$wec_general_options = get_option( 'wec_general_options' );
		$wec_product_options = get_option( 'wec_product_options' );
		$wec_cart_options = get_option( 'wec_cart_options' );
	*/
	
	$wec_general_options = wec_get_options( 'wec_general_options' );
	$wec_product_options = wec_get_options( 'wec_product_options' );
	$wec_cart_options = wec_get_options( 'wec_cart_options' );
	$wec_checkout_options = wec_get_options( 'wec_checkout_options' );

	// echo "<pre>";
	// print_r($wec_checkout_options);
	// echo "</pre>";


	/*General Tab Snippets*/
	include_once 'cart-customization-cmb2/general/woo-hide-mini-cart-widget.php';
	include_once 'cart-customization-cmb2/general/woo-show-checkout-on-cart-empty.php';
	include_once 'cart-customization-cmb2/general/woo-merge-cart-checkout-page.php';
	include_once 'cart-customization-cmb2/general/woo-change-continue-shopping-link.php';

	/*Product Tab Snippets*/
	include_once 'cart-customization-cmb2/product/woo-exclude-hidden-product-from-mini-cart-counter.php';
	include_once 'cart-customization-cmb2/product/woo-change-product-price-based-on-quantity-in-cart.php';
	include_once 'cart-customization-cmb2/product/woo-add-product-on-visiting-specific-page.php';
	
	/*Cart Tab Snippets*/
	include_once 'cart-customization-cmb2/cart/woo-split-cart-table-alphabetically.php';
	include_once 'cart-customization-cmb2/cart/woo-remove-product-link-from-cart-page.php';

	/*Checkout Tab Snippets*/
	include_once 'cart-customization-cmb2/checkout/woo-simplify-checkout-on-virtual-product.php';
	include_once 'cart-customization-cmb2/checkout/woo-remove-or-move-coupon-form.php';


?>