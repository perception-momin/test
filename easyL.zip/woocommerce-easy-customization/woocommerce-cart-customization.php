<?php
/**
 * Plugin Name: WooCommerce Easy Customization
 * Plugin URI: https://perceptionsystem.com/
 * Description: This is the Addon to the WooCommerce to customize the cart functionality with various possible options.
 * Version: 1.0.0
 * Author: Perception System
 * Author URI: https://perceptionsystem.com
 * Text Domain: woocommerce
 * Domain Path: /languages/
 */

add_action( 'plugins_loaded', 'wec_cart_customization_init', 10 );
function wec_cart_customization_init() {
    //if condition use to do nothin while WooCommerce is not installed
	if ( ! class_exists( 'WooCommerce' ) ) return;
	
	if ( file_exists( __DIR__ . '/cmb2/init.php' ) ) {
		require_once __DIR__ . '/cmb2/init.php';
	} elseif ( file_exists( __DIR__ . '/CMB2/init.php' ) ) {
		require_once __DIR__ . '/CMB2/init.php';
	}

	wec_frontend_in_action_callback();
}

/**
 * Hook in and register a metabox to handle a theme options page and adds a menu item.
 */
function wec_register_general_options_metabox() {
	include_once 'admin/tab-general.php';
	include_once 'admin/tab-product.php';
	include_once 'admin/tab-cart.php';
	include_once 'admin/tab-checkout.php';
}
add_action( 'cmb2_admin_init', 'wec_register_general_options_metabox' );

function wec_frontend_in_action_callback(){
	include_once 'public/init.php';
}

function wec_add_js_for_repeatable_titles() {
	add_action( is_admin() ? 'admin_footer' : 'wp_footer', 'wec_add_js_for_repeatable_titles_to_footer' );
}

function wec_add_js_for_repeatable_titles_to_footer() {
	?>
	<script type="text/javascript">
	jQuery( function( $ ) {
		var $box = $( document.getElementById( 'wec_general_options_page' ) );
		var replaceTitles = function() {
			$box.find( '.cmb-group-title' ).each( function() {
				var $this = $( this );
				var txt = $this.next().find( '[id$="title"]' ).val();
				var rowindex;
				if ( ! txt ) {
					txt = $box.find( '[data-grouptitle]' ).data( 'grouptitle' );
					if ( txt ) {
						rowindex = $this.parents( '[data-iterator]' ).data( 'iterator' );
						txt = txt.replace( '{#}', ( rowindex + 1 ) );
					}
				}
				if ( txt ) {
					$this.text( txt );
				}
			});
		};
		var replaceOnKeyUp = function( evt ) {
			var $this = $( evt.target );
			var id = 'title';
			if ( evt.target.id.indexOf(id, evt.target.id.length - id.length) !== -1 ) {
				$this.parents( '.cmb-row.cmb-repeatable-grouping' ).find( '.cmb-group-title' ).text( $this.val() );
			}
		};
		$box
			.on( 'cmb2_add_row cmb2_remove_row cmb2_shift_rows_complete', replaceTitles )
			.on( 'keyup', replaceOnKeyUp );
		replaceTitles();
	});
	</script>
	<?php
}


/*Callback function related to the */
function wec_options_display_with_tabs( $cmb_options ) {
	$tabs = wec_options_page_tabs( $cmb_options );
	?>
	<div class="wrap cmb2-options-page option-<?php echo $cmb_options->option_key; ?>">
		<?php if ( get_admin_page_title() ) : ?>
			<h2><?php echo wp_kses_post( get_admin_page_title() ); ?></h2>
		<?php endif; ?>
		<h2 class="nav-tab-wrapper">
			<?php foreach ( $tabs as $option_key => $tab_title ) : ?>
				<a class="nav-tab<?php if ( isset( $_GET['page'] ) && $option_key === $_GET['page'] ) : ?> nav-tab-active<?php endif; ?>" href="<?php menu_page_url( $option_key ); ?>"><?php echo wp_kses_post( $tab_title ); ?></a>
			<?php endforeach; ?>
		</h2>
		<form class="cmb-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="POST" id="<?php echo $cmb_options->cmb->cmb_id; ?>" enctype="multipart/form-data" encoding="multipart/form-data">
			<input type="hidden" name="action" value="<?php echo esc_attr( $cmb_options->option_key ); ?>">
			<?php $cmb_options->options_page_metabox(); ?>
			<?php submit_button( esc_attr( $cmb_options->cmb->prop( 'save_button' ) ), 'primary', 'submit-cmb' ); ?>
		</form>
	</div>
	<?php
}

function wec_options_page_tabs( $cmb_options ) {
	$tab_group = $cmb_options->cmb->prop( 'tab_group' );
	$tabs      = array();
	foreach ( CMB2_Boxes::get_all() as $cmb_id => $cmb ) {
		if ( $tab_group === $cmb->prop( 'tab_group' ) ) {
			$tabs[ $cmb->options_page_keys()[0] ] = $cmb->prop( 'tab_title' )
				? $cmb->prop( 'tab_title' )
				: $cmb->prop( 'title' );
		}
	}
	return $tabs;
}

function wec_get_page_list(){
	$pages_array = array();
	$pages = get_pages(); 
	foreach ($pages as $page_data) {
	    $pages_array[$page_data->ID] = $page_data->post_title; 
	}
	return $pages_array;    
}

function wec_get_product_list(){
	$products_array = array();
	$args     = array( 'post_type' => 'product', 'posts_per_page' => -1 );
	$products = get_posts( $args ); 
	foreach ($products as $products_data) {
	    $products_array[$products_data->ID] = $products_data->post_title; 
	}
	return $products_array;
}

function wec_get_options($option_name){
	$option_data = get_option( $option_name );
	return $option_data;
}

function wec_get_option($option_name = null, $option_key = null){
	$option_data = get_option( $option_name );
	$option_value = $option_data[$option_key];
	return $option_value;
}